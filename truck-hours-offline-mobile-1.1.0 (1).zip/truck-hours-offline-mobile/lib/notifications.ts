import * as Notifications from "expo-notifications";
import { Platform } from "react-native";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

export async function requestNotificationPermissions() {
  const settings = await Notifications.getPermissionsAsync();
  if (settings.status === "granted") return true;
  const req = await Notifications.requestPermissionsAsync();
  if (Platform.OS === "android") {
    await Notifications.setNotificationChannelAsync("default", {
      name: "Upozornenia",
      importance: Notifications.AndroidImportance.HIGH,
    });
  }
  return req.status === "granted";
}

const lastFired: Record<string, number> = {};
const COOLDOWN_MS = 10 * 60 * 1000; // avoid re-notifying same flag too often

async function fireOnce(key: string, title: string, body: string) {
  const now = Date.now();
  if (lastFired[key] && now - lastFired[key] < COOLDOWN_MS) return;
  lastFired[key] = now;
  await Notifications.scheduleNotificationAsync({
    content: { title, body },
    trigger: null,
  });
}

export async function checkStatusAndNotify(status: {
  needsBreakSoon: boolean;
  breakOverdue: boolean;
  dailyLimitWarning: boolean;
  dailyLimitExceeded: boolean;
  weeklyRestDue: boolean;
}) {
  if (status.breakOverdue) {
    await fireOnce("breakOverdue", "Prestávka je nutná", "Prekročil si 4,5 h nepretržitej jazdy. Zastav a urob prestávku 45 min.");
  } else if (status.needsBreakSoon) {
    await fireOnce("needsBreakSoon", "Blíži sa povinná prestávka", "Do konca povoleného nepretržitého úseku jazdy ostáva menej ako 30 min.");
  }
  if (status.dailyLimitExceeded) {
    await fireOnce("dailyLimitExceeded", "Prekročený denný limit jazdy", "Dnes si prekročil povolený denný limit jazdy.");
  } else if (status.dailyLimitWarning) {
    await fireOnce("dailyLimitWarning", "Blíži sa denný limit jazdy", "Ostáva menej ako 1 h do vyčerpania denného limitu jazdy.");
  }
  if (status.weeklyRestDue) {
    await fireOnce("weeklyRestDue", "Týždenný odpočinok", "Mal by si čoskoro nastúpiť na týždenný odpočinok.");
  }
}
