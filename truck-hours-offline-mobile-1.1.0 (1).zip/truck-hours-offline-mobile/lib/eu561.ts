// Practical EU 561/2006 helper calculations.
// This is not a certified tachograph. It provides driver-facing guidance from recorded
// activities and deliberately requires an explicit rest activity for break credit.

export type SessionType = "driving" | "availability" | "work" | "rest";

export interface RawSession {
  id: number;
  type: SessionType;
  startTime: Date;
  endTime: Date | null;
  breakFirstPart: boolean;
}

export interface DriverSettings {
  extendedDrivingEnabled: boolean;
  reducedRestEnabled: boolean;
}

export const LIMITS = {
  CONTINUOUS_DRIVING: 4.5 * 3600,
  BREAK_REQUIRED: 45 * 60,
  BREAK_FIRST_PART: 15 * 60,
  BREAK_SECOND_PART: 30 * 60,
  DAILY_DRIVING_NORMAL: 9 * 3600,
  DAILY_DRIVING_EXTENDED: 10 * 3600,
  EXTENDED_DRIVING_DAYS_PER_WEEK: 2,
  DAILY_REST_NORMAL: 11 * 3600,
  DAILY_REST_REDUCED: 9 * 3600,
  WEEKLY_DRIVING: 56 * 3600,
  BIWEEKLY_DRIVING: 90 * 3600,
  WEEKLY_REST_NORMAL: 45 * 3600,
  WEEKLY_REST_REDUCED: 24 * 3600,
  WEEKLY_REST_DUE_AFTER: 6 * 24 * 3600,
};

export type BreakState = "none" | "firstPending" | "firstDone";

function dur(session: RawSession, now: Date): number {
  const end = session.endTime ?? now;
  return Math.max(0, (end.getTime() - session.startTime.getTime()) / 1000);
}

function overlapSeconds(session: RawSession, rangeStart: Date, rangeEnd: Date, now: Date): number {
  const sessionEnd = session.endTime ?? now;
  const start = session.startTime > rangeStart ? session.startTime : rangeStart;
  const end = sessionEnd < rangeEnd ? sessionEnd : rangeEnd;
  return end > start ? (end.getTime() - start.getTime()) / 1000 : 0;
}

function startOfCalendarWeek(value: Date, timezoneOffsetMinutes: number): Date {
  // Convert the driver's local wall-clock time to a UTC-shaped Date, find local Monday 00:00,
  // then convert that wall-clock boundary back to a real UTC instant.
  const localWallClock = new Date(value.getTime() - timezoneOffsetMinutes * 60_000);
  localWallClock.setUTCHours(0, 0, 0, 0);
  const daysSinceMonday = (localWallClock.getUTCDay() + 6) % 7;
  localWallClock.setUTCDate(localWallClock.getUTCDate() - daysSinceMonday);
  return new Date(localWallClock.getTime() + timezoneOffsetMinutes * 60_000);
}

export function computeStatus(
  sessionsAsc: RawSession[],
  settings: DriverSettings,
  now = new Date(),
  timezoneOffsetMinutes = 0,
) {
  const dailyDrivingLimit = settings.extendedDrivingEnabled
    ? LIMITS.DAILY_DRIVING_EXTENDED
    : LIMITS.DAILY_DRIVING_NORMAL;
  const dailyRestThreshold = settings.reducedRestEnabled
    ? LIMITS.DAILY_REST_REDUCED
    : LIMITS.DAILY_REST_NORMAL;

  if (sessionsAsc.length === 0) {
    return {
      now: now.toISOString(),
      currentSession: null as null | { id: number; type: SessionType; startTime: string; elapsedSeconds: number },
      continuousDrivingSeconds: 0,
      continuousDrivingLimit: LIMITS.CONTINUOUS_DRIVING,
      breakOverdue: false,
      needsBreakSoon: false,
      breakAccumSeconds: 0,
      breakRequiredSeconds: LIMITS.BREAK_REQUIRED,
      breakRemainingSeconds: LIMITS.BREAK_REQUIRED,
      breakState: "none" as BreakState,
      breakFirstPartAccumSeconds: 0,
      breakFirstPartRequiredSeconds: LIMITS.BREAK_FIRST_PART,
      breakSecondPartAccumSeconds: 0,
      breakSecondPartRequiredSeconds: LIMITS.BREAK_SECOND_PART,
      canFlagFirstPart: false,
      breaksCompletedToday: 0,
      hasDrivenToday: false,
      activeBreakSlot: 1 as 1 | 2,
      secondBreakAvailable: settings.extendedDrivingEnabled,
      dailyDrivingSeconds: 0,
      dailyDrivingLimit,
      dailyLimitExceeded: false,
      dailyLimitWarning: false,
      dayStart: now.toISOString(),
      weeklyDrivingSeconds: 0,
      weeklyDrivingLimit: LIMITS.WEEKLY_DRIVING,
      biweeklyDrivingSeconds: 0,
      biweeklyDrivingLimit: LIMITS.BIWEEKLY_DRIVING,
      biweeklyLimitExceeded: false,
      weekStart: startOfCalendarWeek(now, timezoneOffsetMinutes).toISOString(),
      extendedDrivingDaysUsed: 0,
      extendedDrivingDaysLimit: LIMITS.EXTENDED_DRIVING_DAYS_PER_WEEK,
      extendedDrivingDaysRemaining: LIMITS.EXTENDED_DRIVING_DAYS_PER_WEEK,
      lastDailyRest: null,
      lastWeeklyRest: null,
      weeklyRestDue: false,
      restProgress: null,
      settings,
    };
  }

  let lastDailyRest: { endTime: Date; durationSeconds: number } | null = null;
  let lastWeeklyRest: { endTime: Date; durationSeconds: number } | null = null;

  for (const session of sessionsAsc) {
    if (session.type !== "rest" || !session.endTime) continue;
    const duration = dur(session, now);
    if (duration >= LIMITS.DAILY_REST_REDUCED) {
      lastDailyRest = { endTime: session.endTime, durationSeconds: duration };
    }
    if (duration >= LIMITS.WEEKLY_REST_REDUCED) {
      lastWeeklyRest = { endTime: session.endTime, durationSeconds: duration };
    }
  }

  const dayStart = lastDailyRest ? lastDailyRest.endTime : sessionsAsc[0].startTime;

  let continuousDriving = 0;
  let breakState: BreakState = "none";
  let breakAccum = 0;
  let firstPartAccum = 0;
  let secondPartAccum = 0;
  let breaksCompletedSinceDayStart = 0;
  let hasDrivenSinceDayStart = false;
  let hasDrivenSinceLastBreak = false;

  const resetInProgressBlock = () => {
    breakAccum = 0;
    if (breakState === "firstPending") {
      breakState = "none";
      firstPartAccum = 0;
    } else if (
      breakState === "firstDone" &&
      secondPartAccum > 0 &&
      secondPartAccum < LIMITS.BREAK_SECOND_PART
    ) {
      // The second part must be one uninterrupted block of at least 30 minutes.
      secondPartAccum = 0;
    }
  };

  const completeBreak = () => {
    continuousDriving = 0;
    breakState = "none";
    breakAccum = 0;
    firstPartAccum = 0;
    secondPartAccum = 0;
    hasDrivenSinceLastBreak = false;
    breaksCompletedSinceDayStart += 1;
  };

  for (const session of sessionsAsc) {
    const duration = dur(session, now);

    if (session.type === "driving") {
      resetInProgressBlock();
      continuousDriving += duration;
      hasDrivenSinceDayStart = true;
      hasDrivenSinceLastBreak = true;
    } else if (session.type === "rest") {
      if (hasDrivenSinceLastBreak) {
        if (breakState === "none" && session.breakFirstPart) {
          breakState = "firstPending";
          firstPartAccum = 0;
        }

        if (breakState === "firstPending") {
          firstPartAccum += duration;
          if (firstPartAccum >= LIMITS.BREAK_FIRST_PART) {
            const overflow = firstPartAccum - LIMITS.BREAK_FIRST_PART;
            firstPartAccum = LIMITS.BREAK_FIRST_PART;
            breakState = "firstDone";
            secondPartAccum = overflow;
            if (secondPartAccum >= LIMITS.BREAK_SECOND_PART) completeBreak();
          }
        } else if (breakState === "firstDone") {
          secondPartAccum += duration;
          if (secondPartAccum >= LIMITS.BREAK_SECOND_PART) completeBreak();
        } else {
          breakAccum += duration;
          if (breakAccum >= LIMITS.BREAK_REQUIRED) {
            completeBreak();
          } else if (breakAccum >= LIMITS.BREAK_FIRST_PART) {
            breakState = "firstDone";
            firstPartAccum = LIMITS.BREAK_FIRST_PART;
            secondPartAccum = breakAccum - LIMITS.BREAK_FIRST_PART;
            breakAccum = 0;
          }
        }
      }

      if (session.endTime && duration >= LIMITS.DAILY_REST_REDUCED) {
        continuousDriving = 0;
        breakState = "none";
        breakAccum = 0;
        firstPartAccum = 0;
        secondPartAccum = 0;
        breaksCompletedSinceDayStart = 0;
        hasDrivenSinceDayStart = false;
        hasDrivenSinceLastBreak = false;
      }
    } else {
      // Work and availability are not automatically treated as recuperation breaks.
      resetInProgressBlock();
    }
  }

  const activeBreakSlot: 1 | 2 = breaksCompletedSinceDayStart >= 1 ? 2 : 1;
  const secondBreakAvailable = settings.extendedDrivingEnabled;

  let dailyDrivingSeconds = 0;
  for (const session of sessionsAsc) {
    if (session.type === "driving") {
      dailyDrivingSeconds += overlapSeconds(session, dayStart, now, now);
    }
  }

  const weekStart = startOfCalendarWeek(now, timezoneOffsetMinutes);
  const previousWeekStart = new Date(weekStart.getTime() - 7 * 24 * 3600 * 1000);
  let weeklyDrivingSeconds = 0;
  let biweeklyDrivingSeconds = 0;

  for (const session of sessionsAsc) {
    if (session.type !== "driving") continue;
    weeklyDrivingSeconds += overlapSeconds(session, weekStart, now, now);
    biweeklyDrivingSeconds += overlapSeconds(session, previousWeekStart, now, now);
  }

  let segmentDriving = 0;
  let segmentEnd = sessionsAsc[0].startTime;
  let extendedDrivingDaysUsed = 0;

  const countSegment = () => {
    if (segmentEnd >= weekStart && segmentDriving > LIMITS.DAILY_DRIVING_NORMAL) {
      extendedDrivingDaysUsed += 1;
    }
  };

  for (const session of sessionsAsc) {
    if (session.type === "driving") {
      segmentDriving += dur(session, now);
      segmentEnd = session.endTime ?? now;
    }
    if (session.type === "rest" && session.endTime && dur(session, now) >= LIMITS.DAILY_REST_REDUCED) {
      segmentEnd = session.endTime;
      countSegment();
      segmentDriving = 0;
    }
  }
  segmentEnd = now;
  countSegment();

  const extendedDrivingDaysRemaining = Math.max(
    0,
    LIMITS.EXTENDED_DRIVING_DAYS_PER_WEEK - extendedDrivingDaysUsed,
  );

  const last = sessionsAsc[sessionsAsc.length - 1];
  const currentSession =
    last.endTime === null
      ? {
          id: last.id,
          type: last.type,
          startTime: last.startTime.toISOString(),
          elapsedSeconds: dur(last, now),
        }
      : null;

  let restProgress: null | {
    elapsedSeconds: number;
    dailyRestThreshold: number;
    weeklyRestThreshold: number;
    satisfiesDaily: boolean;
    satisfiesWeekly: boolean;
  } = null;

  if (currentSession?.type === "rest") {
    restProgress = {
      elapsedSeconds: currentSession.elapsedSeconds,
      dailyRestThreshold,
      weeklyRestThreshold: LIMITS.WEEKLY_REST_REDUCED,
      satisfiesDaily: currentSession.elapsedSeconds >= dailyRestThreshold,
      satisfiesWeekly: currentSession.elapsedSeconds >= LIMITS.WEEKLY_REST_REDUCED,
    };
  }

  const breakProgressSeconds =
    breakState === "firstDone"
      ? LIMITS.BREAK_FIRST_PART + secondPartAccum
      : breakState === "firstPending"
        ? firstPartAccum
        : breakAccum;

  const weeklyRestDue = lastWeeklyRest
    ? now.getTime() - lastWeeklyRest.endTime.getTime() >= LIMITS.WEEKLY_REST_DUE_AFTER * 1000
    : now.getTime() - sessionsAsc[0].startTime.getTime() >= LIMITS.WEEKLY_REST_DUE_AFTER * 1000;

  return {
    now: now.toISOString(),
    currentSession,
    continuousDrivingSeconds: continuousDriving,
    continuousDrivingLimit: LIMITS.CONTINUOUS_DRIVING,
    breakOverdue: continuousDriving >= LIMITS.CONTINUOUS_DRIVING,
    needsBreakSoon:
      currentSession?.type === "driving" &&
      LIMITS.CONTINUOUS_DRIVING - continuousDriving <= 30 * 60 &&
      LIMITS.CONTINUOUS_DRIVING - continuousDriving > 0,
    breakAccumSeconds: breakProgressSeconds,
    breakRequiredSeconds: LIMITS.BREAK_REQUIRED,
    breakRemainingSeconds: Math.max(0, LIMITS.BREAK_REQUIRED - breakProgressSeconds),
    breakState,
    breakFirstPartAccumSeconds: firstPartAccum,
    breakFirstPartRequiredSeconds: LIMITS.BREAK_FIRST_PART,
    breakSecondPartAccumSeconds: secondPartAccum,
    breakSecondPartRequiredSeconds: LIMITS.BREAK_SECOND_PART,
    canFlagFirstPart:
      breakState === "none" && currentSession?.type === "rest" && hasDrivenSinceLastBreak,
    breaksCompletedToday: breaksCompletedSinceDayStart,
    hasDrivenToday: hasDrivenSinceDayStart,
    activeBreakSlot,
    secondBreakAvailable,
    dailyDrivingSeconds,
    dailyDrivingLimit,
    dailyLimitExceeded: dailyDrivingSeconds >= dailyDrivingLimit,
    dailyLimitWarning: dailyDrivingLimit - dailyDrivingSeconds <= 3600 && dailyDrivingLimit - dailyDrivingSeconds > 0,
    dayStart: dayStart.toISOString(),
    weeklyDrivingSeconds,
    weeklyDrivingLimit: LIMITS.WEEKLY_DRIVING,
    biweeklyDrivingSeconds,
    biweeklyDrivingLimit: LIMITS.BIWEEKLY_DRIVING,
    biweeklyLimitExceeded: biweeklyDrivingSeconds >= LIMITS.BIWEEKLY_DRIVING,
    weekStart: weekStart.toISOString(),
    extendedDrivingDaysUsed,
    extendedDrivingDaysLimit: LIMITS.EXTENDED_DRIVING_DAYS_PER_WEEK,
    extendedDrivingDaysRemaining,
    lastDailyRest: lastDailyRest
      ? { endTime: lastDailyRest.endTime.toISOString(), durationSeconds: lastDailyRest.durationSeconds }
      : null,
    lastWeeklyRest: lastWeeklyRest
      ? { endTime: lastWeeklyRest.endTime.toISOString(), durationSeconds: lastWeeklyRest.durationSeconds }
      : null,
    weeklyRestDue,
    restProgress,
    settings,
  };
}
